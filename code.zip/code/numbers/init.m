function X = init(N, dim, lb, ub)
    % 初始化一个N x dim的矩阵X，元素值在[lb, ub]之间
    X = rand(N, dim) .* (ub - lb) + lb;
end