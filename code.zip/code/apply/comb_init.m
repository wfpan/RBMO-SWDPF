function pop = comb_init(popsize,dim,lb, ub,fobj)
    X1 = init_point(popsize, dim, lb, ub);  % 使用init_point函数生成种群
   % Tent混沌映射序列
    z = rand(popsize, dim); % 随机序列
    for i=1:popsize
        for j=1:dim
            if z(i,j)<0.5
                z(i,j) = 2*z(i,j);
            elseif z(i)>=0.5
                z(i,j) = 2*(1-z(i,j));
            end
        end
    end
    pop=X1.*z;
end

function pop = init_point(pop_size,dimension,lb, ub)
    lb =  lb .* ones(1,dimension);          %  Variables Lower Bound
    ub =  ub .* ones(1,dimension);          %  Variables Upper Bound
    bounds=[lb',ub'];
    %佳点集生成初始种群
    p = zeros(pop_size,dimension);
    prime_number_min = dimension*2 +3;
    % 找到(prime_number_min-3)/2>=dimension的最小素数prime_number_min
    while 1
        if isprime(prime_number_min)==1
            break;
        else
           prime_number_min = prime_number_min + 1;
        end
    end

    for i = 1:pop_size
        for j = 1:dimension
            r = mod(2*cos(2*pi*j/prime_number_min)*i,1);% 对应维度的r
    %         r = mod(exp(j)*i,1);
            p(i,j) = bounds(j,1)+r*(bounds(j,2)-bounds(j,1));
        end
    end
    pop = p;
end

