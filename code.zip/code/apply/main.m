clear, clc, close all
year="Engineering design problems";
%% 使用CEC2022测试
var="COMPARE";
Func_names_ED_problems = ["WBD","CSD","PVD","SRD","GTD","TBTD","CBD","GTCD"]
repeat_numbers = 3;
Algorithms_name = ["RBMO-SWDPF",  "PSO","HHO","DOA","ALA","FORDBO","GNHGWO"];
%%
funcs = {@IMRBMO, @PSO,@HHO,@DOA,@ALA,@FORDBO,@GNHGWO};
Algorithms_numbers = length(Algorithms_name);
Func_numbers=length(Func_names_ED_problems);
Average_fitness = zeros(Func_numbers, Algorithms_numbers);
Std_fitness=zeros(Func_numbers, Algorithms_numbers);
Gbest_fitness=zeros(Func_numbers, Algorithms_numbers);
popsize = 30; % 种群数量
maxIter = 500; % 最大迭代次数
%%        
Best_fitness_csv=zeros(repeat_numbers,Func_numbers,Algorithms_numbers);
Iter_curve_csv=zeros(repeat_numbers,Func_numbers,Algorithms_numbers,maxIter);
figure('Position', [100, 100, 1600, 800]);  % 创建一个较大的图形窗口
for index = 1:Func_numbers
    [lb, ub, dim] = benchmark_functions_details(index);
    fobj=benchmark_functions(index);
    Best_fitness = zeros(repeat_numbers, Algorithms_numbers);
    Best_pos = zeros(repeat_numbers, Algorithms_numbers, dim);
    Iter_curve = zeros(repeat_numbers, Algorithms_numbers, maxIter); 
    % 求解
    for repeat_index = 1:repeat_numbers
        for i = 1:Algorithms_numbers
            [Best_fitness(repeat_index, i), Best_pos(repeat_index, i, :), Iter_curve(repeat_index, i, :)] = funcs{i}(popsize, dim, maxIter, lb, ub, fobj);
        end
    end
    
    Best_fitness_csv(:,index,:)=Best_fitness;
    Iter_curve_csv(:,index,:,:)=Iter_curve(:,:,:);
    
    Average_fitness(index,:)=mean(Best_fitness,1);
    Std_fitness(index,:)=std(Best_fitness,1);
    Gbest_fitness(index,:)=min(Best_fitness,[],1);
    %% 绘制箱图
	subplot(3, 4, index)  % 将每个函数放到 4x8 的网格中
    boxplot(Best_fitness, 'Whisker', 1.5,'Labels', Algorithms_name);  % 绘制箱形图，'Whisker'控制胡须的长度
    title(sprintf('%s Function %s', year, Func_names_ED_problems(index)));
    xlabel('Algorithm Category');
    ylabel('Average Fitness');
end
%% save name
filename=sprintf('%s-repeat_number%d-popsize%d-maxIter%d',year,repeat_numbers, popsize, maxIter);

% 保存箱图到文件（例如 PNG 格式）% 创建动态文件名
if ~exist('figure_box', 'dir')
        % 创建文件夹
        mkdir('figure_box');
        fprintf('文件夹已创建: %s\n', 'figure_box');
    else
        fprintf('文件夹已存在: %s\n', 'figure_box');
    end
boxplot_filename = fullfile('figure_box', strcat(var,'-',filename, '.pdf'));
exportgraphics(gcf, boxplot_filename );

%% csv Fitness
FITNESS_foldername = strcat('FITNESS', '--', filename);
% 检查文件夹是否已经存在
    if ~exist(FITNESS_foldername, 'dir')
        % 创建文件夹
        mkdir(FITNESS_foldername);
        fprintf('文件夹已创建: %s\n', FITNESS_foldername);
    else
        fprintf('文件夹已存在: %s\n', FITNESS_foldername);
    end
% 创建动态文件名
FITNESS_filename = fullfile(FITNESS_foldername, strcat(filename, '.xlsx'));
row_titles_cell = cellstr(Func_names_ED_problems);  % 将数字数组转换为单元格数组
col_titles_cell = cellstr(Algorithms_name);
% 组合成完整数据矩阵

sheet_data=Average_fitness;
data_with_titles = [ {''}, col_titles_cell; row_titles_cell', num2cell(sheet_data)];  % 添加行和列标题
writecell(data_with_titles, FITNESS_filename, 'Sheet', 'Average', 'Range', 'A1');

for i = 1:repeat_numbers
    sheet_data = squeeze(Best_fitness_csv(i, :, :));
    data_with_titles = [ {''}, col_titles_cell; row_titles_cell', num2cell(sheet_data)];  % 添加行和列标题
    % 使用 writematrix 写入 Excel 文件，每个矩阵存储到不同的 sheet 中
    sheet_name = ['repeat ' num2str(i)];
    writecell(data_with_titles, FITNESS_filename, 'Sheet', sheet_name, 'Range', 'A1');
end
% %% csv Position
% POSITION_folder_name = strcat('POSITION', '--', filename);
% 
% % 检查文件夹是否已经存在
%     if ~exist(POSITION_folder_name, 'dir')
%         % 创建文件夹
%         mkdir(POSITION_folder_name);
%         fprintf('文件夹已创建: %s\n', POSITION_folder_name);
%     else
%         fprintf('文件夹已存在: %s\n', POSITION_folder_name);
%     end
%     
% % 假设我们在每个文件中写入相应的函数名
% for i = 1:length(Func_names_ED_problems)
%     % 获取函数名作为文件夹名称
%     Func_folder_name =fullfile(POSITION_folder_name,char(Func_names_ED_problems(i)));
%     
%     % 检查文件夹是否已存在
%     if ~exist(Func_folder_name, 'dir')
%         % 创建文件夹
%         mkdir(Func_folder_name);
%         fprintf('文件夹已创建: %s\n', Func_folder_name);
%     else
%         fprintf('文件夹已存在: %s\n', Func_folder_name);
%     end
%     
%     % 生成Excel文件名
%     POSITION_filename = fullfile(Func_folder_name,strcat(filename, '.xlsx'));
%     
%     for j = 1:repeat_numbers
%         % 获取当前的数据
%         sheet_data =  squeeze(Position_csv(j,i, :, :));
%         % 合并行列标题与数据
%         data_with_titles = [col_titles_cell', num2cell(sheet_data)];
%         
%         sheet_name = ['repeat ' num2str(i)];
%         writecell(data_with_titles, POSITION_filename, 'Sheet', sheet_name, 'Range', 'A1');
%     end
% end
% 
% disp('数据已成功存入 Excel 文件');
%% csv curve
CURVE_folder_name = strcat('CURVE', '--', filename);

% 检查文件夹是否已经存在
    if ~exist(CURVE_folder_name, 'dir')
        % 创建文件夹
        mkdir(CURVE_folder_name);
        fprintf('文件夹已创建: %s\n', CURVE_folder_name);
    else
        fprintf('文件夹已存在: %s\n', CURVE_folder_name);
    end
    
% 假设我们在每个文件中写入相应的函数名
for i = 1:length(Func_names_ED_problems)
    % 获取函数名作为文件夹名称
    Func_folder_name =fullfile(CURVE_folder_name,char(Func_names_ED_problems(i)));
    
    % 检查文件夹是否已存在
    if ~exist(Func_folder_name, 'dir')
        % 创建文件夹
        mkdir(Func_folder_name);
        fprintf('文件夹已创建: %s\n', Func_folder_name);
    else
        fprintf('文件夹已存在: %s\n', Func_folder_name);
    end
    
    % 生成Excel文件名
    CURVE_filename = fullfile(Func_folder_name,strcat(filename, '.xlsx'));
    
    for j = 1:repeat_numbers
        % 获取当前的数据
        sheet_data =  squeeze(Iter_curve_csv(j,i, :, :));
        % 合并行列标题与数据
        data_with_titles = [col_titles_cell', num2cell(sheet_data)];
        
        sheet_name = ['repeat ' num2str(i)];
        writecell(data_with_titles, CURVE_filename, 'Sheet', sheet_name, 'Range', 'A1');
    end
end

disp('数据已成功存入 Excel 文件');
%% 表格1 mean
% 创建一个图形窗口并生成一个uitable
fig1 = uifigure("Position", [500 500 760 360],'Name', year+'-mean');

% 创建一个uitable，设置其大小为填满整个窗口
h = uitable(fig1, 'Data', num2cell(round(Average_fitness, 2)), ...
            'ColumnName', Algorithms_name, ...
            'RowName', Func_names_ED_problems, ...
            'Position', [20 20 500 300]);

% 创建字体加粗样式
sBold = uistyle("FontWeight", "bold");  % 字体加粗样式
% 创建黄色背景色样式
yellowBackground = uistyle("BackgroundColor", [1 1 0]);  % 黄色背景色

% 遍历每一行，找到最小值并应用加粗字体和黄色背景
for row = 1:Func_numbers
    [~, col] = min(Average_fitness(row, :));  % 找到每行最小值的列索引
    % 为该单元格应用加粗样式
    addStyle(h, sBold, "cell", [row, col]);
    % 为该单元格应用黄色背景色
    addStyle(h, yellowBackground, "cell", [row, col]);
end
%% 表格2 std
% 创建一个图形窗口并生成一个uitable
fig2 = uifigure("Position", [500 500 760 360],'Name',  year+'-std');

% 创建一个uitable，设置其大小为填满整个窗口
h = uitable(fig2, 'Data', num2cell(round(Std_fitness, 2)), ...
            'ColumnName', Algorithms_name, ...
            'RowName', Func_names_ED_problems, ...
            'Position', [20 20 500 300]);

% 创建字体加粗样式
sBold = uistyle("FontWeight", "bold");  % 字体加粗样式
% 创建黄色背景色样式
yellowBackground = uistyle("BackgroundColor", [1 1 0]);  % 黄色背景色

% 遍历每一行，找到最小值并应用加粗字体和黄色背景
for row = 1:Func_numbers
    [~, col] = min(Std_fitness(row, :));  % 找到每行最小值的列索引
    % 为该单元格应用加粗样式
    addStyle(h, sBold, "cell", [row, col]);
    % 为该单元格应用黄色背景色
    addStyle(h, yellowBackground, "cell", [row, col]);
end
%% 表格3 Best
% 创建一个图形窗口并生成一个uitable
fig3 = uifigure("Position", [500 500 760 360],'Name',  year+ '-best');

% 创建一个uitable，设置其大小为填满整个窗口
h = uitable(fig3, 'Data', num2cell(round(Gbest_fitness, 2)), ...
            'ColumnName', Algorithms_name, ...
            'RowName', Func_names_ED_problems, ...
            'Position', [20 20 500 300]);

% 创建字体加粗样式
sBold = uistyle("FontWeight", "bold");  % 字体加粗样式
% 创建黄色背景色样式
yellowBackground = uistyle("BackgroundColor", [1 1 0]);  % 黄色背景色

% 遍历每一行，找到最小值并应用加粗字体和黄色背景
for row = 1:Func_numbers
    [~, col] = min(Gbest_fitness(row, :));  % 找到每行最小值的列索引
    % 为该单元格应用加粗样式
    addStyle(h, sBold, "cell", [row, col]);
    % 为该单元格应用黄色背景色
    addStyle(h, yellowBackground, "cell", [row, col]);
end